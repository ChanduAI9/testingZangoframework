from django.shortcuts import render, redirect
from .models import Todo

# View for displaying the to-do list
def todo_list(request):
    todos = Todo.objects.all()  # Fetch all Todo items from the database
    return render(request, 'todo_list.html', {'todos': todos})
# View for adding a new to-do item
def add_todo_view(request):
    if request.method == "POST":
        title = request.POST.get("title")
        Todo.objects.create(title=title)
        return redirect("todo_list")
    return render(request, "add_todo.html")

# View for marking a to-do item as done
def mark_done_view(request, todo_id):
    todo = Todo.objects.get(id=todo_id)
    todo.completed = True
    todo.save()
    return redirect("todo_list")

# View for deleting a to-do item
def delete_todo_view(request, todo_id):
    todo = Todo.objects.get(id=todo_id)
    todo.delete()
    return redirect("todo_list")
