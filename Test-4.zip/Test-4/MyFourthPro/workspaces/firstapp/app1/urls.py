from django.urls import path
from . import views

urlpatterns = [
    path('', views.todo_list, name='todo_list'),   
   path("add/", views.add_todo_view, name="add_todo"),
    path("done/<int:todo_id>/", views.mark_done_view, name="mark_done"),
    path("delete/<int:todo_id>/", views.delete_todo_view, name="delete_todo"),
]
