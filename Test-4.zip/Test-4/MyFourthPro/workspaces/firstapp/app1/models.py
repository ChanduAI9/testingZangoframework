# from zango.apps.dynamic_models.models import DynamicModelBase
from django.db import models
# from django.contrib.auth.models import AbstractUser

# class AppUserModel(AbstractUser):
#     groups = models.ManyToManyField(
#         "auth.Group",
#         related_name="custom_user_groups",  # Avoid conflicts
#         blank=True,
#     )
#     user_permissions = models.ManyToManyField(
#         "auth.Permission",
#         related_name="custom_user_permissions",  # Avoid conflicts
#         blank=True,
#     )


# class Todo(DynamicModelBase):
#     title = models.CharField(max_length=200)
#     completed = models.BooleanField(default=False)

#     created_by = models.ForeignKey(
#         "firstapp.app1.AppUserModel",
#         on_delete=models.SET_NULL,
#         null=True,
#         related_name="todos_created",  # Unique related_name
#     )
#     modified_by = models.ForeignKey(
#         "firstapp.app1.AppUserModel",
#         on_delete=models.SET_NULL,
#         null=True,
#         related_name="todos_modified",  # Unique related_name
#     )

#     class Meta:
#         managed = True


from zango.apps.dynamic_models.models import DynamicModelBase
from django.contrib.auth.models import User

# class Todo(models.Model):
#     title = models.CharField(max_length=200)
#     created_at = models.DateTimeField(auto_now_add=True)
#     modified_at = models.DateTimeField(auto_now=True)
#     created_by = models.ForeignKey(
#         User, on_delete=models.CASCADE, related_name='created_todos'
#     )
#     modified_by = models.ForeignKey(
#         User, on_delete=models.CASCADE, related_name='modified_todos'
#     )
#     def __str__(self):
#         return self.title
    
from  django.utils.timezone import now
from zango.apps.dynamic_models.models import DynamicModelBase
from django.contrib.auth.models import User


class Todo(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table="dynamic_models_todo"
        
    def __str__(self):
        return self.title