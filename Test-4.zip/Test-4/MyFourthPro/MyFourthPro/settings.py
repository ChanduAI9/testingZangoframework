from pathlib import Path
import os
import sys
from zango.config.settings.base import *

BASE_DIR = Path(__file__).resolve().parent.parent  # Corrected BASE_DIR to use Path

sys.path.append(BASE_DIR / "workspaces")  # Updated for consistency with Path

class AttrDict(dict):
    def __getattr__(self, item):
        return globals()[item]

    def __setattr__(self, item, value):
        globals()[item] = value

    def __setitem__(self, key, value):
        globals()[key] = value

# Call setup_settings to initialize the settings
settings_result = setup_settings(AttrDict(vars()), BASE_DIR)

SECRET_KEY = "django-insecure-4_bg2a(nzol_@=evn4et48#4l^q)hc6ao_um3^*9zq7vt7hjde"  # Consider moving to .env

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [
            BASE_DIR / 'workspaces' / 'firstapp' / 'app1' / 'templates',
        ],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "zango.apps.dynamic_models",
    "zango.apps.object_store",
    "zango.apps.auditlogs",
    "zango.apps.permissions",
    "zango.apps.appauth",
    "zango.apps.shared.tenancy",
    "zango.apps.shared.platformauth",
    "axes",
    "knox",
    "crispy_forms",
    "django_celery_results",
    "django_celery_beat",
    "zango.apps.tasks",
    "workspaces.firstapp.app1",
    "session_security",
]

CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"

ROOT_URLCONF = "MyFourthPro.urls_public"

CRISPY_TEMPLATE_PACK = "bootstrap4"

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django_tenants.middleware.main.TenantMainMiddleware',
      'axes.middleware.AxesMiddleware',  # Required for Django Tenants
]




DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# MIGRATION_MODULES = {
#     'firstapp': 'firstapp.custom_migrations'
# }

DATABASES = {
    'default': {
        'ENGINE': 'django_tenants.postgresql_backend',  # Or any other database backend
        'NAME': 'test4',
        'USER': 'postgres',
        'PASSWORD': '1229',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}

TENANT_MODEL = "tenancy.TenantModel"
TENANT_DOMAIN_MODEL = "tenancy.Domain"
PUBLIC_SCHEMA_NAME = "public"
DATABASE_ROUTERS = ["django_tenants.routers.TenantSyncRouter"]

ROOT_URLCONF = 'MyFourthPro.urls'
