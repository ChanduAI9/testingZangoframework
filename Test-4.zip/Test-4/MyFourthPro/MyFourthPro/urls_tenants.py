from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("zango.config.urls_tenants")),
    # path('todo/', include('firstapp.app1.urls')),
    path("app1/",include("workspaces.firstapp.app1.urls")),

]
