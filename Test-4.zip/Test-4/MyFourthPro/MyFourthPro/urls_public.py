from django.contrib import admin
from django.urls import include, path
from django.http import HttpResponse
from django.shortcuts import render
# def debug_view(request):
#     return HttpResponse("<h1>Debugging Route Works</h1>")

def debug_template_view(request):
    return render(request, "todo_list.html")

urlpatterns = [
    # path("admin/", admin.site.urls),
    path("", include("zango.config.urls_public")),  # Use dynamic routing
    # path("debug/",debug_view),
    path("debug_template/",debug_template_view),
    path("",include("workspaces.firstapp.app1.urls")),


]


