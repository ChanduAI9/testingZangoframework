FE Issues:
- Page Title font etc.
- Add New Workflow (Btn, Sidedrawer)
- Sort Icon
- Search by items should be in proper case
- Search result not reflecting properly in table
- Page change not working
- Sort result not reflecting in table
- pagination not working
- page size not reflecting in table
- Href type for element (e.g. no underline)


Row Actions:
- Two types of Row Actions: Form based & Simple 
- Simple Action Workflow: Select a row, click on Action, FE to show a confirmation dialog then post data to backend with Row ID and action key
- Form Action Workflow: Select a row, click on Action, FE to render form on side drawer, which will then be submitted to backend 



BE Issues:
- Check for all column types



Form:
- Extra Attributes 
- clean methods
- unique, unique together etc.


Actions Workflow:
- BE & FE

Filters, Columns Management workflow: Later



- gracefully handle view not found 
