import "./style.css";
import "./src/modules/detail/index.js";