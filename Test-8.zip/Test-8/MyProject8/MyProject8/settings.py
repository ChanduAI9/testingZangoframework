from pathlib import Path
import os
import sys
from zango.config.settings.base import *

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, BASE_DIR / "workspaces")


class AttrDict(dict):
    """
    A dictionary subclass for managing global settings with attribute-style access.

    This class allows getting and setting items in the global namespace
    using both attribute and item notation.
    """

    def __getattr__(self, item):
        return globals()[item]

    def __setattr__(self, item, value):
        globals()[item] = value

    def __setitem__(self, key, value):
        globals()[key] = value


# Call setup_settings to initialize the settings
settings_result = setup_settings(AttrDict(vars()), BASE_DIR)

# Setting Overrides
# Any settings that need to be overridden or added should be done below this line
# to ensure they take effect after the initial setup

SECRET_KEY = "django-insecure-@)rh$%y-&2%5a(8%qtra^w0z-&*6+bnrj7#*jv5_n8$#sdtgv0"  # Shift this to .env


# To change the media storage to S3 you can use the BACKEND class provided by the default storage
# To change the static storage to S3 you can use the BACKEND class provided by the staticfiles storage
# STORAGES = {
#     "default": {"BACKEND": "zango.core.storage_utils.S3MediaStorage"},
#     "staticfiles": {"BACKEND": "zango.core.storage_utils.S3StaticStorage"},
# }


# INTERNAL_IPS can contain a list of IP addresses or CIDR blocks that are considered internal.
# Both individual IP addresses and CIDR notation (e.g., '192.168.1.1' or '192.168.1.0/24') can be provided.


#template render

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [
            Path(BASE_DIR) / "workspaces" / "FirstApp" / "templates",
        ],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "zango.apps.dynamic_models",
    "zango.apps.object_store",
    "zango.apps.auditlogs",
    "zango.apps.permissions",
    "zango.apps.appauth",
    "zango.apps.shared.tenancy",
    "zango.apps.shared.platformauth",
    "axes",
    "knox",
    "crispy_forms",
    "django_celery_results",
    "django_celery_beat",
    "zango.apps.tasks",
    "session_security",
    "workspaces.FirstApp",
    # "FirstApp",
    "rest_framework",

]

CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"

ROOT_URLCONF = "MyProject8.urls"

CRISPY_TEMPLATE_PACK = "bootstrap4"

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "axes.middleware.AxesMiddleware",
    "django_tenants.middleware.main.TenantMainMiddleware",
    # "django_tenants.middleware.TenantMiddleware",

]

# TENANT_MODEL = "tenancy.TenantModel"
# TENANT_MODEL = "FirstApp.Tenant"


PUBLIC_SCHEMA_NAME = "public"

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

DATABASE_ROUTERS = ["django_tenants.routers.TenantSyncRouter"]

ROOT_URLCONF = 'zango.config.urls_public'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'DEBUG',
    },
}


DATABASES = {
    'default': {
        'ENGINE': 'django_tenants.postgresql_backend',
        'NAME': 'test8',
        'USER': 'postgres',
        'PASSWORD': '1229',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}


DEBUG =True