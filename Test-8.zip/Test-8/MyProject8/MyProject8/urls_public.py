from django.urls import path, include

urlpatterns = [
    path("auth/", include("django.contrib.auth.urls")),  # Authentication-related endpoints
    path("api/todos", include("workspaces.FirstApp.urls")), 
    path("session_security/", include("session_security.urls")),
    path("platform/", include("zango.config.urls_platform")),
]





